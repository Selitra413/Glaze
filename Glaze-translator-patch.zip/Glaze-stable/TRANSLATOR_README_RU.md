# Glaze: отдельный визуальный переводчик (экспериментальная доработка)

Эта версия основана на присланном `Glaze-stable.zip`. Изменения затрагивают только исходный проект; готовый Windows `.exe` **не** собран и не испытан в работающем Flutter-приложении.

## Возможности

1. **API → Translator**: отдельные адрес OpenAI-совместимого API, ключ и имя модели (например, `https://api.deepseek.com/v1`, `deepseek-chat`). Нажмите «Сохранить подключение».
2. В чате откройте меню **трёх точек** у ответа ассистента и выберите **Translate to Russian**.
3. Русский текст постепенно появляется **на месте** английского в том же сообщении. Во время генерации можно выбрать **Stop translation**. После завершения — **Show original**.
4. Оригинальный английский текст всегда сохраняется для истории, промптов, редактирования и команды Copy. Переводы не записываются в базу и пропадают при закрытии приложения. Смена текущего сеанса отменяет перевод.
5. Перевод выполняет **отдельная** модель через `POST /chat/completions` с `stream: true`. Другие протоколы, в частности Responses API, не реализованы.

## Windows: сборка

Выполнять из папки проекта с установленным Flutter SDK, Visual Studio с «Desktop development with C++» и зависимостями Flutter:

```powershell
flutter pub get
flutter analyze
flutter test test/translation_config_test.dart
flutter test test/api_settings_tab_order_test.dart
flutter build windows --release
```

Найти результат можно в `build/windows/x64/runner/Release/`. **Не заменяйте только один EXE:** Flutter-программе обычно нужен весь каталог сборки вместе с библиотеками и ресурсами. Для отдельной установки рядом с обычным Glaze стоит собирать/запускать в обособленном каталоге данных и заранее сохранить резервную копию `glaze.db`.

Без Flutter можно провести проверку JS-части:

```powershell
node --check assets/chat_webview/bridge/chat_bridge_controller.js
node test/manual/translation_bridge_smoke.mjs
```

## Замечания

- Входящий текст отправляется выбранному стороннему поставщику API. Не отправляйте личную или закрытую информацию без согласия на такую обработку.
- API-ключ хранится локально в SharedPreferences, **не в защищённом хранилище**. Избегайте общедоступных устройств и чрезмерно привилегированных ключей.
- Встроен потоковый протокол OpenAI Chat Completions (SSE); совместимость с конкретным провайдером нужно проверить на Windows. Провайдеры, которые игнорируют `stream: true` и отвечают одним JSON, поддерживаются ограниченно.
- После изменения файлов `assets/chat_webview` нужен **полный перезапуск** приложения (hot reload недостаточно).
- Сообщения пользователя, ошибки и сообщения во время генерации не переводятся кнопкой; кнопка доступна у готового ответа.
- Исходная модель и программа SillyTavern здесь ни при чём: переводчик работает только внутри Glaze.

## Изменённые файлы

- `lib/features/translation/translation_service.dart` — настройки и потоковый API-клиент.
- `lib/features/translation/translator_settings_panel.dart` — интерфейс.
- `lib/features/settings/api_settings_screen.dart` — четвёртая вкладка Translator.
- `lib/features/chat/widgets/message_actions.dart` — кнопка в меню.
- `lib/features/chat/chat_screen.dart` — запросы, отмена и временные состояния.
- `lib/features/chat/bridge/chat_bridge_controller.dart`, `lib/features/chat/widgets/chat_webview_widget.dart` — команды в WebView.
- `assets/chat_webview/bridge/chat_bridge_controller.js` — слой перевода без изменения сырого текста.
- `test/translation_config_test.dart`, `test/api_settings_tab_order_test.dart`, `test/manual/translation_bridge_smoke.mjs` — проверки.
